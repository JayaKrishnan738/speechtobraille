const input = document.getElementById('input');
const output = document.getElementById('output');
if ("webkitSpeechRecognition" in window) {
  let speechRecognition = new webkitSpeechRecognition();
  let final_transcript = "";

  speechRecognition.continuous = true;
  speechRecognition.interimResults = true;
  speechRecognition.lang = document.querySelector("#select_dialect").value;

  speechRecognition.onstart = () => {
    console.log("called")
    document.querySelector("#status").style.display = "block";
  };
  speechRecognition.onerror = (e) => {
    console.log(e)
    document.querySelector("#status").style.display = "none";
    console.log("Speech Recognition Error");
  };
  speechRecognition.onend = () => {
    document.querySelector("#status").style.display = "none";
    console.log("Speech Recognition Ended");
  };

  speechRecognition.onresult = (event) => {
    let interim_transcript = "";

    for (let i = event.resultIndex; i < event.results.length; ++i) {
      if (event.results[i].isFinal) {
        final_transcript += event.results[i][0].transcript;

      } else {
        interim_transcript += event.results[i][0].transcript;
      }
    }

    document.querySelector("#final").innerHTML = final_transcript;
    document.querySelector("#interim").innerHTML = interim_transcript;

    //---------Braille code starts here------------
    var inp = document.querySelector("#final").innerHTML;



    var map = {
      'a': '&#10241;',
      'b': '&#10243;',
      'c': '&#10249;',
      'd': '&#10265;',
      'e': '&#10257;',
      'f': '&#10251;',
      'g': '&#10267;',
      'h': '&#10259;',
      'i': '&#10250;',
      'j': '&#10266;',
      'k': '&#10245;',
      'l': '&#10247;',
      'm': '&#10281;',
      'n': '&#10269;',
      'o': '&#10261;',
      'p': '&#10255;',
      'q': '&#10271;',
      'r': '&#10263;',
      's': '&#10254;',
      't': '&#10270;',
      'u': '&#10277;',
      'v': '&#10300;',
      'w': '&#10298;',
      'x': '&#10285;',
      'y': '&#10301;',
      'z': '&#10293;',
      ' ': '&emsp;'
    };
    //lowercasing the inputs 
    var theInput = inp.toLowerCase();
    var arr = "";
    //  Loop through characters in input string
    for (var i = 0; i < theInput.length; i++) {

      //  Store character in variable
      var letter = theInput.charAt(i);

      //  Check character is letter (between a - z) or space
      if (letter.match(/[a-z\s]/i)) {

        //  Match letter to Braille Symbol
        var symbol = map[letter];

        //  Add Braille symbol to output element

        arr += symbol;


      }//   End if

    }// End for loop
    document.querySelector("#braille").innerHTML = arr;
    //--------braille code ends here------------
  };


  document.querySelector("#start").onclick = () => {
    speechRecognition.start();
  };
  document.querySelector("#stop").onclick = () => {
    speechRecognition.stop();


  };
} else {
  console.log("Speech Recognition Not Available");
}

//clear button function
document.querySelector("#clear").onclick = () => {

  document.querySelector("#braille").innerHTML = "";
  document.querySelector("#final").innerHTML = "";
};

